package com.botviper.dashboard

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText
import java.net.SocketTimeoutException
import java.net.UnknownHostException

class PylonLoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pylon_login)

        val panelUrlInput = findViewById<TextInputEditText>(R.id.panelUrlInput)
        val usernameInput = findViewById<TextInputEditText>(R.id.usernameInput)
        val passwordInput = findViewById<TextInputEditText>(R.id.passwordInput)
        val errorText = findViewById<TextView>(R.id.errorText)
        val loginButton = findViewById<Button>(R.id.loginButton)
        val progress = findViewById<ProgressBar>(R.id.loginProgress)

        val prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
        prefs.getString(Prefs.PYLON_PANEL_URL, null)?.let { panelUrlInput.setText(it) }
        prefs.getString(Prefs.PYLON_USERNAME, null)?.let { usernameInput.setText(it) }

        loginButton.setOnClickListener {
            var panelUrl = panelUrlInput.text?.toString()?.trim().orEmpty()
            val username = usernameInput.text?.toString()?.trim().orEmpty()
            val password = passwordInput.text?.toString()?.trim().orEmpty()

            if (panelUrl.isEmpty() || username.isEmpty() || password.isEmpty()) {
                errorText.text = "Điền đủ địa chỉ panel, username và mật khẩu"
                return@setOnClickListener
            }
            if (!panelUrl.startsWith("http://") && !panelUrl.startsWith("https://")) {
                panelUrl = "http://$panelUrl"
            }
            panelUrl = panelUrl.trimEnd('/')
            errorText.text = ""
            progress.visibility = View.VISIBLE
            loginButton.isEnabled = false

            PylonApi(panelUrl).login(username, password) { result ->
                runOnUiThread {
                    progress.visibility = View.GONE
                    loginButton.isEnabled = true
                    result.onSuccess { info ->
                        prefs.edit()
                            .putString(Prefs.PYLON_PANEL_URL, panelUrl)
                            .putString(Prefs.PYLON_TOKEN, info.token)
                            .putString(Prefs.PYLON_USERNAME, info.username)
                            .apply()
                        startActivity(Intent(this, PylonBotListActivity::class.java))
                        finish()
                    }.onFailure {
                        errorText.text = friendlyLoginError(it)
                    }
                }
            }
        }
    }

    /** Turns raw network exceptions into the same clear Vietnamese wording used on the dashboard setup screen. */
    private fun friendlyLoginError(e: Throwable): String = when (e) {
        is SocketTimeoutException ->
            "Không kết nối được panel (hết thời gian chờ). Kiểm tra điện thoại và Termux có cùng mạng Wi-Fi, và panel (npm start) đã chạy chưa."
        is UnknownHostException ->
            "Không tìm thấy địa chỉ panel này. Kiểm tra lại IP/domain đã nhập đúng chưa."
        else -> {
            val msg = e.message.orEmpty()
            when {
                "ECONNREFUSED" in msg || "refused" in msg.lowercase() ->
                    "Panel từ chối kết nối. Kiểm tra panel Node.js (npm start) đã bật và đúng cổng chưa."
                msg.isNotBlank() -> msg
                else -> "Đăng nhập thất bại"
            }
        }
    }
}
