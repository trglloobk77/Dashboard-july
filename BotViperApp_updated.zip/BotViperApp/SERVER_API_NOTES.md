# API mà app bản mới cần ở PYLON Panel (server/*.js)

Bản app cập nhật vẫn dùng đúng các route cũ (`/api/auth/login`, `/api/bots`,
`/api/bots/:id/start|stop|restart`, `/api/bots/:id/logs`, `/ws/logs`) —
**không cần sửa gì cũng chạy được**, chỉ là 3 phần mới (Kill, gửi lệnh console,
CPU/RAM/Uptime) sẽ tự ẩn/báo lỗi nhẹ nhàng nếu panel chưa hỗ trợ. Muốn có full
tính năng như Pterodactyl thật thì thêm phần dưới đây vào panel Node.js hiện có.

## 1. Nút "Kill" (dừng cứng)
Dùng lại đúng route pattern cũ, chỉ thêm 1 action:

```
POST /api/bots/:id/kill
```
Khác với `stop` (dừng êm ái, chờ tiến trình tự thoát), `kill` nên gọi thẳng
`process.kill(pid, 'SIGKILL')` trong `runner.js` — dùng khi bot bị treo và
`stop` không ăn thua.

## 2. Gửi lệnh vào console (stdin)
```
POST /api/bots/:id/command
Body: { "command": "say hello" }
```
Route này ghi thẳng vào `stdin` của child process đang chạy (giống gõ lệnh
trực tiếp trong `tmux attach`). Nếu bot đang tắt, trả lỗi 400 với
`{ "error": "Bot chưa chạy" }` — app sẽ hiện lỗi này dạng Toast.

## 3. CPU / RAM / Uptime theo thời gian thực
App đã tự parse thêm các field optional này nếu có mặt trong response của
`GET /api/bots` và `GET /api/bots/:id` (field nào thiếu thì app tự hiện "—"):

```json
{
  "id": "abc123",
  "name": "MyBot",
  "runtime": "node18",
  "status": "running",
  "ramMb": 256,
  "cpuPercent": 3.2,
  "ramUsedMb": 118,
  "ramLimitMb": 512,
  "uptimeSec": 5423
}
```
Gợi ý lấy `cpuPercent`/`ramUsedMb` trên Termux: đọc `/proc/<pid>/stat` +
`/proc/<pid>/status`, hoặc dùng package `pidusage` (nhẹ, không cần biên dịch
native, chạy tốt trên Termux).

## 4. (Tuỳ chọn) GET /api/bots/:id
Nếu chưa có route lấy chi tiết 1 bot, có thể bỏ qua — app vẫn hoạt động vì
màn điều khiển đang lấy dữ liệu qua `GET /api/bots` (danh sách) rồi lọc theo id.
Thêm route riêng này chỉ giúp polling nhẹ hơn khi có nhiều bot.
