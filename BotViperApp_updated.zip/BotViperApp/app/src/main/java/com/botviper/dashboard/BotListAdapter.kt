package com.botviper.dashboard

import android.graphics.PorterDuff
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView

class BotListAdapter(
    private val onClick: (PylonApi.BotInfo) -> Unit
) : RecyclerView.Adapter<BotListAdapter.VH>() {

    private val bots = mutableListOf<PylonApi.BotInfo>()

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val dot: View = view.findViewById(R.id.statusDot)
        val name: TextView = view.findViewById(R.id.botName)
        val meta: TextView = view.findViewById(R.id.botMeta)
        val status: TextView = view.findViewById(R.id.botStatus)
    }

    /** Replace the whole list, diffing so only changed rows repaint (no full-list flicker on refresh). */
    fun submitBots(newBots: List<PylonApi.BotInfo>) {
        val diff = DiffUtil.calculateDiff(object : DiffUtil.Callback() {
            override fun getOldListSize() = bots.size
            override fun getNewListSize() = newBots.size
            override fun areItemsTheSame(oldPos: Int, newPos: Int) =
                bots[oldPos].id == newBots[newPos].id
            override fun areContentsTheSame(oldPos: Int, newPos: Int) =
                bots[oldPos] == newBots[newPos]
        })
        bots.clear()
        bots.addAll(newBots)
        diff.dispatchUpdatesTo(this)
    }

    fun currentBots(): List<PylonApi.BotInfo> = bots

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_bot, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val bot = bots[position]
        holder.name.text = bot.name

        val ramText = if (bot.ramUsedMb >= 0 && bot.ramLimitMb > 0) {
            "${bot.ramUsedMb}/${bot.ramLimitMb}MB"
        } else {
            "${bot.ramMb}MB"
        }
        val cpuText = if (bot.cpuPercent >= 0) " · CPU ${"%.0f".format(bot.cpuPercent)}%" else ""
        holder.meta.text = "${bot.runtime} · $ramText$cpuText"
        holder.status.text = bot.status.replaceFirstChar { it.uppercase() }

        val color = when (bot.status) {
            "running" -> R.color.pylon_success
            "building", "starting" -> R.color.pylon_warning
            "error", "crashed" -> R.color.pylon_danger
            else -> R.color.pylon_muted
        }
        val resolved = holder.itemView.context.getColor(color)
        holder.dot.background.setColorFilter(resolved, PorterDuff.Mode.SRC_IN)
        holder.status.setTextColor(resolved)

        holder.itemView.setOnClickListener { onClick(bot) }
    }

    override fun getItemCount() = bots.size
}
